# Downloads


To get everything this project has to offer, you will need to download lists from links in this repository.

While a few small files are available for download from within the repo, the rest can only be acquired via Torrent or Mega.NZ download.

You have the ability to download all files at once, or one at a time.

## Please Seed!
Make sure that others have the same access to the files that you did!



|Torrent Files| Download Size |
| --- | --- |
| [Real-Passwords , 7z Compressed - Torrent](Real-Passwords/Real-Password-Rev-2-Torrents/ProbWL-v2-Real-Passwords-7z.torrent)| 5.0 G.B |
| [Real-Passwords, tar.gz Compressed - Torrent](Real-Passwords/Real-Password-Rev-2-Torrents/ProbWL-v2-Real-Passwords-targz.torrent)| 8.0 GB |
| | |
| [Real-WPA-Passwords, 7z Compressed - Torrent](Real-Passwords/WPA-Length/WPA-Length-Rev-2-Torrents/ProbWL-v2-Real-WPA-Passwords-7z.torrent)| 4.27 GB |
| [Real-WPA-Passwords, tar.gz Compressed - Torrent](Real-Passwords/WPA-Length/WPA-Length-Rev-2-Torrents/ProbWL-v2-Real-WPA-Passwords-targz.torrent) | 7.48 GB |
| | |
| [Dictionary-Style Files, 7z Compressed - Torrent](Dictionary-Style/Dictionary-Style-Rev-2-Torrents/ProbWL-v2-Dictionary-Style-7z.torrent)|468.8 MB |
| [Dictionary-Style Files, tar.gz Compressed - Torrent](Dictionary-Style/Dictionary-Style-Rev-2-Torrents/ProbWL-v2-Dictionary-Style-targz.torrent)| 598.2 MB|
| | |
| [Analysis-Files, 7z Compressed - Torrent](Analysis-Files/Analysis-Files-Torrents/ProbWL-v2-Analysis-Files-7z.torrent)| 284.2 MB |
| [Analysis-Files, tar.gz Compressed - Torrent](Analysis-Files/Analysis-Files-Torrents/ProbWL-v2-Analysis-Files-targz.torrent)| 416.8 MB |

<br>
<br>

|MegaLinks |
| --- |
| [Real-Passwords](Real-Passwords/Real-Passwords-MegaLinks.md)|
| [Real-WPA-Passwords](Real-Passwords/WPA-Length/Real-Password-WPA-MegaLinks.md)|
| [Dictionary-Style Files](Dictionary-Style/Dictionary-Style-MegaLinks.md)|
| [Analysis-Files](Analysis-Files/Analysis-Files-Megalinks.md)|



<br>

#### Recommended Unarchivers:
* Windows: __7Zip__
* Mac: __Keka__
* Linux: Command Line, __p7zip__

#### Recommended Torrent Client:
* __Deluge__ gave me the best results in terms of connecting to the seedbox.


***

![Probable Wordlists Logo](https://raw.githubusercontent.com/berzerk0/Probable-Wordlists/master/ProbableWordlistLogo.png)

## Disclaimer and License
 + These lists are for LAWFUL, ETHICAL AND EDUCATIONAL PURPOSES ONLY.
 + The files contained in this repository are released "as is" without warranty, support, or guarantee of effectiveness.
 + *However, I am open to hearing about any issues found within these files and will be actively maintaining this repository for the foreseeable future. If you find anything noteworthy, let me know and I'll see what I can do about it.*

 [![License: CC BY-SA 4.0](https://img.shields.io/badge/License-CC%20BY--SA%204.0-lightgrey.svg)](http://creativecommons.org/licenses/by-sa/4.0/)

 __This work is licensed under a [Creative Commons Attribution-ShareAlike 4.0 International License.](https://creativecommons.org/licenses/by-sa/4.0/)__


<br>

Enjoy!

<br>
This file was last updated on 20 Feb, 2018.
